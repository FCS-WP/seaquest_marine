(function($){
	"use strict";

	$(window).on('elementor/frontend/init', function () {

		
		

   });
})(jQuery);
